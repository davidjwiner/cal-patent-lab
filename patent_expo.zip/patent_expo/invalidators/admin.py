from invalidators.models import File
from django.contrib import admin

admin.site.register(File)